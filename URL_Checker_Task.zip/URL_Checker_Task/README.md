-------------------------------------------------
URL Checker Task – JavaScript Implementation
-------------------------------------------------

Author: Nirali Kachhadiya

Description:
A small browser application that allows a user to check
if an entered URL exists. It validates the URL format and
uses a simulated asynchronous server call to return mock
results for "file", "folder", or "not found".

Main Features:
- URL format validation using RegExp
- Mock server call using setTimeout (asynchronous)
- Debounce mechanism (600 ms delay)
- Status messages with color-coded feedback

How to Run:
1. Open index.html in any modern browser.
2. Type a URL (e.g., https://example.com) to see live validation.
3. Try typing:
   - "https://example.com/" → folder
   - "https://example.com/file.json" → file
   - "https://notfound.com" → not found

Technologies Used:
- HTML, CSS, JavaScript (ES6)

Notes:
This project simulates server behavior on the client side
only. No external APIs are used.

-------------------------------------------------